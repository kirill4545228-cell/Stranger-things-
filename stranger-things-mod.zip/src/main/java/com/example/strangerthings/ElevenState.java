package com.example.strangerthings;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;
import net.minecraft.world.PersistentStateManager;

public class ElevenState extends PersistentState {
    private final Set<UUID> unlocked = new HashSet<>();

    public static ElevenState get(MinecraftServer server) {
        PersistentStateManager manager = server.getOverworld().getPersistentStateManager();
        return manager.getOrCreate(ElevenState::fromNbt, ElevenState::new, "strangerthings_eleven");
    }

    public static ElevenState fromNbt(NbtCompound nbt) {
        ElevenState state = new ElevenState();
        NbtList list = nbt.getList("unlocked", NbtElement.STRING_TYPE);
        for (int i = 0; i < list.size(); i++) {
            try {
                state.unlocked.add(UUID.fromString(list.getString(i)));
            } catch (IllegalArgumentException ignored) {
            }
        }
        return state;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt) {
        NbtList list = new NbtList();
        for (UUID id : unlocked) {
            list.add(NbtString.of(id.toString()));
        }
        nbt.put("unlocked", list);
        return nbt;
    }

    public boolean isUnlocked(UUID id) {
        return unlocked.contains(id);
    }

    /** @return true if it was newly unlocked */
    public boolean unlock(UUID id) {
        boolean added = unlocked.add(id);
        if (added) markDirty();
        return added;
    }
}
