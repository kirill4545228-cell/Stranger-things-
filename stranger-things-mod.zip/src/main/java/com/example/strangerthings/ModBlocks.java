package com.example.strangerthings;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModBlocks {
    public static final Block RIFT = Registry.register(Registries.BLOCK,
            new Identifier(StrangerThings.MOD_ID, "rift"),
            new RiftBlock(AbstractBlock.Settings.create()
                    .noCollision()
                    .nonOpaque()
                    .dropsNothing()
                    .strength(-1.0f, 3600000.0f)
                    .luminance(state -> 12)));

    public static void register() {
    }
}
