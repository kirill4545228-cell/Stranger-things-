package com.example.strangerthings;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.block.BlockState;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

public final class RiftTravel {
    private static final Map<UUID, Integer> COOLDOWN = new HashMap<>();

    private RiftTravel() {
    }

    public static void clear() {
        COOLDOWN.clear();
    }

    public static boolean canPlace(World w, BlockPos p) {
        BlockState s = w.getBlockState(p);
        return s.isAir() || (s.getFluidState().isEmpty() && s.getCollisionShape(w, p).isEmpty());
    }

    public static void placeRift(World w, BlockPos base) {
        for (int i = 0; i < 2; i++) {
            BlockPos p = base.up(i);
            if (canPlace(w, p)) {
                w.setBlockState(p, ModBlocks.RIFT.getDefaultState());
            }
        }
    }

    public static void travel(ServerPlayerEntity p, BlockPos rift) {
        MinecraftServer server = p.getServer();
        if (server == null) return;
        int now = server.getTicks();
        Integer until = COOLDOWN.get(p.getUuid());
        if (until != null && now < until) return;

        ServerWorld from = p.getServerWorld();
        RegistryKey<World> destKey = from.getRegistryKey().equals(StrangerThings.UPSIDE_DOWN)
                ? World.OVERWORLD : StrangerThings.UPSIDE_DOWN;
        ServerWorld dest = server.getWorld(destKey);
        if (dest == null) {
            p.sendMessage(Text.literal("Изнанка не найдена. Создайте новый мир."), true);
            return;
        }
        COOLDOWN.put(p.getUuid(), now + 80);

        int x = rift.getX();
        int z = rift.getZ();
        int y = dest.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
        int ex = x + 2;
        int ey = dest.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, ex, z);
        placeRift(dest, new BlockPos(ex, ey, z));

        from.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_ENDERMAN_TELEPORT,
                SoundCategory.PLAYERS, 1.0f, 0.5f);
        p.teleport(dest, x + 0.5, y, z + 0.5, p.getYaw(), p.getPitch());
        dest.playSound(null, x + 0.5, y, z + 0.5, SoundEvents.ENTITY_ENDERMAN_TELEPORT,
                SoundCategory.PLAYERS, 1.0f, 0.5f);
    }
}
