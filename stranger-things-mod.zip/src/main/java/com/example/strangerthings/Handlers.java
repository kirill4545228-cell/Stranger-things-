package com.example.strangerthings;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.joml.Vector3f;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ChestBlock;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

public final class Handlers {
    private record Origin(RegistryKey<World> dim, double x, double y, double z) {
    }

    private static final Map<UUID, Integer> TANK = new HashMap<>();
    private static final Map<UUID, Origin> ORIGIN = new HashMap<>();
    private static final Map<UUID, Integer> RETURN_AT = new HashMap<>();

    private static final BlockPos CHEST_POS = new BlockPos(0, -62, 3);

    private Handlers() {
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(Handlers::onTick);
        UseBlockCallback.EVENT.register(Handlers::onUseBlock);
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> {
            TANK.clear();
            ORIGIN.clear();
            RETURN_AT.clear();
            RiftTravel.clear();
            ElevenPowerItem.clear();
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("eleven")
                        .executes(ctx -> {
                            ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                            if (!ElevenState.get(ctx.getSource().getServer()).isUnlocked(p.getUuid())) {
                                ctx.getSource().sendError(Text.literal("Вы ещё не обрели силу Одиннадцать."));
                                return 0;
                            }
                            p.giveItemStack(new ItemStack(ModItems.ELEVEN_POWER));
                            return 1;
                        })
                        .then(CommandManager.literal("unlock")
                                .requires(src -> src.hasPermissionLevel(2))
                                .executes(ctx -> {
                                    ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                                    ElevenState.get(ctx.getSource().getServer()).unlock(p.getUuid());
                                    p.giveItemStack(new ItemStack(ModItems.ELEVEN_POWER));
                                    return 1;
                                }))));
    }

    // ---------------------------------------------------------------- tick

    private static void onTick(MinecraftServer server) {
        int now = server.getTicks();
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            UUID id = p.getUuid();
            RegistryKey<World> dim = p.getWorld().getRegistryKey();

            if (dim.equals(StrangerThings.DEPRIVATION)) {
                TANK.remove(id);
                Integer at = RETURN_AT.get(id);
                if ((at != null && now >= at) || p.getY() > -26) {
                    RETURN_AT.remove(id);
                    returnPlayer(p);
                }
                continue;
            }

            if (inTank(p)) {
                int n = TANK.merge(id, 1, Integer::sum);
                if (n == 1) {
                    p.sendMessage(Text.literal("Вокруг тишина... Вы погружаетесь в темноту.")
                            .formatted(Formatting.BLUE), true);
                }
                if (n >= 40) {
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 40, 0, false, false, false));
                }
                if (n >= 100) {
                    TANK.remove(id);
                    enterDeprivation(p);
                }
            } else {
                TANK.remove(id);
            }
        }

        ServerWorld up = server.getWorld(StrangerThings.UPSIDE_DOWN);
        if (up != null) {
            redLightning(up);
        }
    }

    // ---------------------------------------------------------------- tank

    private static boolean inTank(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        BlockPos feet = p.getBlockPos();
        if (!w.getFluidState(feet).isIn(FluidTags.WATER)) return false;
        for (Direction d : Direction.Type.HORIZONTAL) {
            if (!wallIsBlack(w, feet, d)) return false;
            if (!wallIsBlack(w, feet.up(), d)) return false;
        }
        return wallIsBlack(w, feet.up(2), Direction.UP) && wallIsBlack(w, feet.down(), Direction.DOWN);
    }

    private static boolean wallIsBlack(ServerWorld w, BlockPos start, Direction dir) {
        for (int i = 0; i <= 8; i++) {
            BlockState s = w.getBlockState(start.offset(dir, i));
            if (s.isAir() || s.isOf(Blocks.WATER)) continue;
            return s.isOf(Blocks.BLACK_CONCRETE);
        }
        return false;
    }

    private static void enterDeprivation(ServerPlayerEntity p) {
        MinecraftServer server = p.getServer();
        ServerWorld dep = server.getWorld(StrangerThings.DEPRIVATION);
        if (dep == null) {
            p.sendMessage(Text.literal("Тёмное измерение не найдено. Создайте новый мир."), true);
            return;
        }
        buildRoom(dep);
        ORIGIN.put(p.getUuid(), new Origin(p.getWorld().getRegistryKey(), p.getX(), p.getY(), p.getZ()));
        RETURN_AT.remove(p.getUuid());
        p.teleport(dep, 0.5, -45.0, 0.5, 0.0f, 0.0f);
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.WATER_BREATHING, 20 * 60 * 5, 0, false, false, false));
        p.sendMessage(Text.literal("Тишина. Чёрная вода. Где-то внизу виден слабый свет...")
                .formatted(Formatting.DARK_AQUA), false);
    }

    private static void buildRoom(ServerWorld w) {
        if (w.getBlockState(CHEST_POS).isOf(Blocks.CHEST)) return;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = 2; dz <= 4; dz++) {
                w.setBlockState(new BlockPos(dx, -63, dz), Blocks.BLACK_CONCRETE.getDefaultState());
            }
        }
        w.setBlockState(CHEST_POS, Blocks.CHEST.getDefaultState()
                .with(ChestBlock.FACING, Direction.NORTH)
                .with(Properties.WATERLOGGED, true));
        BlockState lantern = Blocks.SOUL_LANTERN.getDefaultState().with(Properties.WATERLOGGED, true);
        w.setBlockState(new BlockPos(-1, -62, 4), lantern);
        w.setBlockState(new BlockPos(1, -62, 4), lantern);
        w.setBlockState(new BlockPos(-1, -62, 2), lantern);
        w.setBlockState(new BlockPos(1, -62, 2), lantern);
    }

    private static void returnPlayer(ServerPlayerEntity p) {
        MinecraftServer server = p.getServer();
        Origin o = ORIGIN.remove(p.getUuid());
        ServerWorld w = null;
        double x;
        double y;
        double z;
        if (o != null) {
            w = server.getWorld(o.dim());
        }
        if (w != null) {
            x = o.x();
            y = o.y();
            z = o.z();
        } else {
            w = server.getOverworld();
            BlockPos sp = w.getSpawnPos();
            x = sp.getX() + 0.5;
            z = sp.getZ() + 0.5;
            y = w.getTopY(Heightmap.Type.MOTION_BLOCKING, sp.getX(), sp.getZ());
        }
        p.removeStatusEffect(StatusEffects.WATER_BREATHING);
        p.teleport(w, x, y, z, p.getYaw(), p.getPitch());
    }

    // --------------------------------------------------------------- chest

    private static ActionResult onUseBlock(PlayerEntity player, World world, Hand hand, BlockHitResult hit) {
        if (world.isClient || !(player instanceof ServerPlayerEntity sp)) return ActionResult.PASS;
        if (!world.getRegistryKey().equals(StrangerThings.DEPRIVATION)) return ActionResult.PASS;
        if (!world.getBlockState(hit.getBlockPos()).isOf(Blocks.CHEST)) return ActionResult.PASS;

        MinecraftServer server = sp.getServer();
        boolean first = ElevenState.get(server).unlock(sp.getUuid());
        if (first) {
            sp.giveItemStack(new ItemStack(ModItems.ELEVEN_POWER));
            sp.sendMessage(Text.literal("Вы ощутили, как внутри просыпается сила Одиннадцать...")
                    .formatted(Formatting.AQUA), false);
            sp.sendMessage(Text.literal("ПКМ по блоку (3 сек) - разрыв, ПКМ по мобу - телекинез, Shift+ПКМ - толчок.")
                    .formatted(Formatting.GRAY), false);
            ((ServerWorld) world).playSound(null, sp.getBlockPos(), SoundEvents.BLOCK_BEACON_ACTIVATE,
                    SoundCategory.PLAYERS, 1.0f, 0.6f);
        } else {
            sp.sendMessage(Text.literal("Сила уже с вами.").formatted(Formatting.AQUA), true);
        }
        RETURN_AT.put(sp.getUuid(), server.getTicks() + 100);
        return ActionResult.PASS;
    }

    // ----------------------------------------------------------- lightning

    private static void redLightning(ServerWorld w) {
        Random r = w.getRandom();
        for (ServerPlayerEntity p : w.getPlayers()) {
            if (r.nextInt(100) != 0) continue;
            double ang = r.nextDouble() * Math.PI * 2.0;
            double dist = 12.0 + r.nextDouble() * 35.0;
            double x = p.getX() + Math.cos(ang) * dist;
            double z = p.getZ() + Math.sin(ang) * dist;
            Vec3d cur = new Vec3d(x, p.getY() + 50.0, z);
            DustParticleEffect red = new DustParticleEffect(new Vector3f(1.0f, 0.05f, 0.05f), 2.0f);
            for (int i = 0; i < 26; i++) {
                cur = cur.add((r.nextDouble() - 0.5) * 2.4, -2.0, (r.nextDouble() - 0.5) * 2.4);
                w.spawnParticles(p, red, true, cur.x, cur.y, cur.z, 3, 0.1, 0.3, 0.1, 0.0);
            }
            w.playSound(null, x, p.getY(), z, SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER,
                    SoundCategory.AMBIENT, 4.0f, 0.5f);
        }
    }
}
