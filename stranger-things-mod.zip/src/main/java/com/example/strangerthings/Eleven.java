package com.example.strangerthings;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * Сила Одиннадцать.
 *
 * R - включить / выключить силу.
 * Когда сила включена и рука пустая:
 *  - Shift + ПКМ: толчок (волна отбрасывает врагов);
 *  - зажать ПКМ, глядя на моба: телекинез (поднять), отпустить - бросить;
 *    пока моб удерживается, он задыхается (урон раз в секунду, игроки не страдают).
 * Цена: кровь из носа (урон и голод).
 */
public final class Eleven {
    public static final Identifier TOGGLE_PACKET = new Identifier(StrangerThings.MOD_ID, "toggle");
    public static final Identifier USE_PACKET = new Identifier(StrangerThings.MOD_ID, "use");

    private static final class State {
        boolean active;
        boolean grabbing;
        int grabStart;
        int cooldownUntil;
        UUID held;
    }

    /** Раз в сколько тиков душит удерживаемого моба (20 тиков = 1 секунда). */
    private static final int CHOKE_INTERVAL = 20;
    /** Урон за один раз (2.0 = одно сердце). */
    private static final float CHOKE_DAMAGE = 2.0f;

    private static final Map<UUID, State> STATES = new HashMap<>();

    private Eleven() {
    }

    public static void register() {
        ServerPlayNetworking.registerGlobalReceiver(TOGGLE_PACKET,
                (server, player, handler, buf, responseSender) -> server.execute(() -> toggle(player)));

        ServerPlayNetworking.registerGlobalReceiver(USE_PACKET, (server, player, handler, buf, responseSender) -> {
            boolean down = buf.readBoolean();
            server.execute(() -> setUse(player, down));
        });

        ServerTickEvents.END_SERVER_TICK.register(Eleven::onTick);
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> STATES.remove(handler.player.getUuid()));
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> STATES.clear());
    }

    private static State state(ServerPlayerEntity p) {
        return STATES.computeIfAbsent(p.getUuid(), id -> new State());
    }

    // ------------------------------------------------------------ input

    private static void toggle(ServerPlayerEntity p) {
        State s = state(p);
        s.active = !s.active;
        if (!s.active) {
            s.grabbing = false;
            s.held = null;
        }
        p.sendMessage(s.active
                ? Text.literal("Сила Одиннадцать: ВКЛ").formatted(Formatting.AQUA)
                : Text.literal("Сила Одиннадцать: ВЫКЛ").formatted(Formatting.GRAY), true);
        p.getServerWorld().playSound(null, p.getX(), p.getY(), p.getZ(),
                s.active ? SoundEvents.BLOCK_BEACON_ACTIVATE : SoundEvents.BLOCK_BEACON_DEACTIVATE,
                SoundCategory.PLAYERS, 0.6f, 1.4f);
    }

    private static void setUse(ServerPlayerEntity p, boolean down) {
        State s = state(p);
        MinecraftServer server = p.getServer();
        if (server == null) return;

        if (!down) {
            if (s.grabbing && s.held != null) {
                throwHeld(p, s);
                s.cooldownUntil = server.getTicks() + 20;
            }
            s.grabbing = false;
            s.held = null;
            return;
        }

        if (!s.active || !p.getMainHandStack().isEmpty()) return;
        if (server.getTicks() < s.cooldownUntil) return;

        if (p.isSneaking()) {
            push(p);
            s.cooldownUntil = server.getTicks() + 40;
            return;
        }
        s.grabbing = true;
        s.grabStart = server.getTicks();
        s.held = null;
    }

    // ------------------------------------------------------------- tick

    private static void onTick(MinecraftServer server) {
        int now = server.getTicks();
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            State s = STATES.get(p.getUuid());
            if (s == null || !s.active || !s.grabbing) continue;

            if (!p.isAlive() || !p.getMainHandStack().isEmpty()) {
                s.grabbing = false;
                s.held = null;
                continue;
            }

            ServerWorld w = p.getServerWorld();
            int used = now - s.grabStart;

            if (s.held == null && used < 30 && used % 3 == 0) {
                LivingEntity target = findTarget(w, p);
                if (target != null) {
                    s.held = target.getUuid();
                }
            }

            if (s.held == null) continue;

            Entity e = w.getEntity(s.held);
            if (e == null || !e.isAlive()) {
                s.held = null;
                s.grabbing = false;
                continue;
            }
            Vec3d want = p.getEyePos().add(p.getRotationVec(1.0f).multiply(4.0));
            Vec3d center = e.getPos().add(0, e.getHeight() / 2.0, 0);
            Vec3d delta = want.subtract(center);
            e.setVelocity(delta.multiply(0.35));
            e.velocityModified = true;
            e.fallDistance = 0;
            w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, center.x, center.y, center.z, 2, 0.3, 0.3, 0.3, 0.0);
            if (used > 0 && used % 20 == 0) {
                nosebleed(p);
            }
            // Удушение: пока моб удерживается, он получает урон раз в секунду.
            if (used > 0 && used % CHOKE_INTERVAL == 0 && e instanceof LivingEntity victim
                    && !(victim instanceof PlayerEntity)) {
                victim.damage(w.getDamageSources().drown(), CHOKE_DAMAGE);
                w.spawnParticles(ParticleTypes.SMOKE, e.getX(), e.getEyeY(), e.getZ(), 6, 0.2, 0.2, 0.2, 0.01);
            }
        }
    }

    // ----------------------------------------------------------- powers

    private static void throwHeld(ServerPlayerEntity p, State s) {
        ServerWorld w = p.getServerWorld();
        Entity e = w.getEntity(s.held);
        if (e == null || !e.isAlive()) return;
        e.setVelocity(p.getRotationVec(1.0f).multiply(2.2));
        e.velocityModified = true;
        w.playSound(null, e.getX(), e.getY(), e.getZ(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM,
                SoundCategory.PLAYERS, 0.5f, 1.4f);
        nosebleed(p);
    }

    private static LivingEntity findTarget(ServerWorld w, ServerPlayerEntity p) {
        Vec3d eye = p.getEyePos();
        Vec3d look = p.getRotationVec(1.0f);
        Box box = p.getBoundingBox().stretch(look.multiply(20.0)).expand(2.0);
        LivingEntity best = null;
        double bestDot = 0.97;
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, box, x -> x != p && x.isAlive())) {
            Vec3d to = e.getPos().add(0, e.getHeight() / 2.0, 0).subtract(eye);
            double dist = to.length();
            if (dist > 20.0 || dist < 0.5) continue;
            double dot = to.normalize().dotProduct(look);
            if (dot > bestDot) {
                bestDot = dot;
                best = e;
            }
        }
        return best;
    }

    private static void push(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        Vec3d look = p.getRotationVec(1.0f);
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(8.0),
                x -> x != p && x.isAlive())) {
            Vec3d to = e.getPos().subtract(p.getPos());
            if (to.lengthSquared() > 64.0 || to.lengthSquared() < 0.01) continue;
            if (to.normalize().dotProduct(look) < 0.3) continue;
            e.setVelocity(look.multiply(2.0).add(0, 0.5, 0));
            e.velocityModified = true;
            e.damage(w.getDamageSources().magic(), 2.0f);
        }
        Vec3d front = p.getEyePos().add(look.multiply(2.0));
        w.spawnParticles(ParticleTypes.SONIC_BOOM, front.x, front.y, front.z, 1, 0, 0, 0, 0);
        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM,
                SoundCategory.PLAYERS, 0.8f, 1.2f);
        nosebleed(p);
    }

    public static void nosebleed(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        w.spawnParticles(DustParticleEffect.DEFAULT, p.getX(), p.getEyeY() - 0.15, p.getZ(),
                6, 0.12, 0.05, 0.12, 0.0);
        p.addExhaustion(2.0f);
        if (p.getHealth() > 4.0f) {
            p.damage(w.getDamageSources().magic(), 1.0f);
        }
    }
}
