package com.example.strangerthings;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

public class ModItems {
    public static final Item ELEVEN_POWER = Registry.register(Registries.ITEM,
            new Identifier(StrangerThings.MOD_ID, "eleven_power"),
            new ElevenPowerItem(new Item.Settings().maxCount(1).rarity(Rarity.EPIC)));

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> entries.add(ELEVEN_POWER));
    }
}
