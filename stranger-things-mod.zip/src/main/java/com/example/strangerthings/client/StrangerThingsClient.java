package com.example.strangerthings.client;

import org.lwjgl.glfw.GLFW;

import com.example.strangerthings.Eleven;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.PacketByteBuf;

public class StrangerThingsClient implements ClientModInitializer {
    private static KeyBinding toggleKey;
    private static boolean lastUse = false;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.strangerthings.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                "category.strangerthings"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) {
                lastUse = false;
                return;
            }

            while (toggleKey.wasPressed()) {
                if (ClientPlayNetworking.canSend(Eleven.TOGGLE_PACKET)) {
                    ClientPlayNetworking.send(Eleven.TOGGLE_PACKET, PacketByteBufs.create());
                }
            }

            boolean use = client.currentScreen == null && client.options.useKey.isPressed();
            if (use != lastUse) {
                lastUse = use;
                if (ClientPlayNetworking.canSend(Eleven.USE_PACKET)) {
                    PacketByteBuf buf = PacketByteBufs.create();
                    buf.writeBoolean(use);
                    ClientPlayNetworking.send(Eleven.USE_PACKET, buf);
                }
            }
        });
    }
}
