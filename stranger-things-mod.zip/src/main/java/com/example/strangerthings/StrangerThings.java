package com.example.strangerthings;

import net.fabricmc.api.ModInitializer;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

public class StrangerThings implements ModInitializer {
    public static final String MOD_ID = "strangerthings";
    public static final RegistryKey<World> UPSIDE_DOWN =
            RegistryKey.of(RegistryKeys.WORLD, new Identifier(MOD_ID, "upside_down"));
    public static final RegistryKey<World> DEPRIVATION =
            RegistryKey.of(RegistryKeys.WORLD, new Identifier(MOD_ID, "deprivation"));

    @Override
    public void onInitialize() {
        ModBlocks.register();
        ModItems.register();
        Handlers.register();
    }
}
