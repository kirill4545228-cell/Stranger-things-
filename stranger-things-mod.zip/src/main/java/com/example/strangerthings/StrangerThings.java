package com.example.strangerthings;

import net.fabricmc.api.ModInitializer;

public class StrangerThings implements ModInitializer {
    public static final String MOD_ID = "strangerthings";

    @Override
    public void onInitialize() {
        Eleven.register();
        UpsideDown.register();
    }
}
