package com.example.strangerthings;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Сила Одиннадцать.
 * - Shift + ПКМ: толчок (волна отбрасывает врагов).
 * - Зажать ПКМ, глядя на моба: телекинез (поднять), отпустить - бросить.
 * - Зажать ПКМ, глядя на блок (3 сек): открыть разрыв в Изнанку.
 * Цена: кровь из носа (урон и голод).
 */
public class ElevenPowerItem extends Item {
    private static final Map<UUID, UUID> HELD = new HashMap<>();

    public ElevenPowerItem(Settings settings) {
        super(settings);
    }

    public static void clear() {
        HELD.clear();
    }

    @Override
    public int getMaxUseTime(ItemStack stack) {
        return 72000;
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return UseAction.NONE;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (user.isSneaking()) {
            if (!world.isClient && user instanceof ServerPlayerEntity sp && canUse(sp)) {
                push(sp);
                sp.getItemCooldownManager().set(this, 40);
            }
            return TypedActionResult.success(stack);
        }
        if (!world.isClient && user instanceof ServerPlayerEntity sp) {
            HELD.remove(sp.getUuid());
            if (!canUse(sp)) {
                return TypedActionResult.fail(stack);
            }
        }
        user.setCurrentHand(hand);
        return TypedActionResult.consume(stack);
    }

    private static boolean canUse(ServerPlayerEntity p) {
        if (p.getWorld().getRegistryKey().equals(StrangerThings.DEPRIVATION)) {
            p.sendMessage(Text.literal("Здесь сила молчит."), true);
            return false;
        }
        if (!ElevenState.get(p.getServer()).isUnlocked(p.getUuid())) {
            p.sendMessage(Text.literal("Вы ещё не обрели силу Одиннадцать."), true);
            return false;
        }
        return true;
    }

    @Override
    public void usageTick(World world, LivingEntity user, ItemStack stack, int remainingUseTicks) {
        if (world.isClient || !(user instanceof ServerPlayerEntity player)) return;
        ServerWorld sw = (ServerWorld) world;
        int used = getMaxUseTime(stack) - remainingUseTicks;
        UUID heldId = HELD.get(player.getUuid());

        if (heldId == null && used < 30 && used % 3 == 0) {
            LivingEntity target = findTarget(sw, player);
            if (target != null) {
                heldId = target.getUuid();
                HELD.put(player.getUuid(), heldId);
            }
        }

        if (heldId != null) {
            Entity e = sw.getEntity(heldId);
            if (e == null || !e.isAlive()) {
                HELD.remove(player.getUuid());
                return;
            }
            Vec3d want = player.getEyePos().add(player.getRotationVec(1.0f).multiply(4.0));
            Vec3d center = e.getPos().add(0, e.getHeight() / 2.0, 0);
            Vec3d delta = want.subtract(center);
            e.setVelocity(delta.multiply(0.35));
            e.velocityModified = true;
            e.fallDistance = 0;
            sw.spawnParticles(ParticleTypes.ELECTRIC_SPARK, center.x, center.y, center.z, 2, 0.3, 0.3, 0.3, 0.0);
            if (used > 0 && used % 20 == 0) {
                nosebleed(player);
            }
            return;
        }

        HitResult hit = player.raycast(6.0, 0.0f, false);
        if (hit.getType() == HitResult.Type.BLOCK) {
            Vec3d pos = hit.getPos();
            sw.spawnParticles(DustParticleEffect.DEFAULT, pos.x, pos.y, pos.z, 2, 0.25, 0.25, 0.25, 0.0);
            if (used == 60) {
                openRift(player, (BlockHitResult) hit);
            }
        }
    }

    @Override
    public void onStoppedUsing(ItemStack stack, World world, LivingEntity user, int remainingUseTicks) {
        if (world.isClient || !(user instanceof ServerPlayerEntity player)) return;
        UUID heldId = HELD.remove(player.getUuid());
        if (heldId == null) return;
        Entity e = ((ServerWorld) world).getEntity(heldId);
        if (e != null && e.isAlive()) {
            e.setVelocity(player.getRotationVec(1.0f).multiply(2.2));
            e.velocityModified = true;
            world.playSound(null, e.getX(), e.getY(), e.getZ(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM,
                    SoundCategory.PLAYERS, 0.5f, 1.4f);
            nosebleed(player);
        }
        player.getItemCooldownManager().set(this, 20);
    }

    private static LivingEntity findTarget(ServerWorld w, ServerPlayerEntity p) {
        Vec3d eye = p.getEyePos();
        Vec3d look = p.getRotationVec(1.0f);
        Box box = p.getBoundingBox().stretch(look.multiply(20.0)).expand(2.0);
        LivingEntity best = null;
        double bestDot = 0.97;
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, box, x -> x != p && x.isAlive())) {
            Vec3d to = e.getPos().add(0, e.getHeight() / 2.0, 0).subtract(eye);
            double dist = to.length();
            if (dist > 20.0 || dist < 0.5) continue;
            double dot = to.normalize().dotProduct(look);
            if (dot > bestDot) {
                bestDot = dot;
                best = e;
            }
        }
        return best;
    }

    private void openRift(ServerPlayerEntity p, BlockHitResult hit) {
        ServerWorld w = p.getServerWorld();
        BlockPos base = hit.getBlockPos().offset(hit.getSide());
        if (!RiftTravel.canPlace(w, base) || !RiftTravel.canPlace(w, base.up())) {
            p.sendMessage(Text.literal("Здесь нельзя открыть разрыв."), true);
            return;
        }
        RiftTravel.placeRift(w, base);
        w.playSound(null, base, SoundEvents.BLOCK_END_PORTAL_SPAWN, SoundCategory.PLAYERS, 0.6f, 1.6f);
        w.spawnParticles(DustParticleEffect.DEFAULT, base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5,
                30, 0.4, 0.8, 0.4, 0.0);
        nosebleed(p);
        p.getItemCooldownManager().set(this, 60);
    }

    private static void push(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        Vec3d look = p.getRotationVec(1.0f);
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(8.0),
                x -> x != p && x.isAlive())) {
            Vec3d to = e.getPos().subtract(p.getPos());
            if (to.lengthSquared() > 64.0 || to.lengthSquared() < 0.01) continue;
            if (to.normalize().dotProduct(look) < 0.3) continue;
            e.setVelocity(look.multiply(2.0).add(0, 0.5, 0));
            e.velocityModified = true;
            e.damage(w.getDamageSources().magic(), 2.0f);
        }
        Vec3d front = p.getEyePos().add(look.multiply(2.0));
        w.spawnParticles(ParticleTypes.SONIC_BOOM, front.x, front.y, front.z, 1, 0, 0, 0, 0);
        w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_WARDEN_SONIC_BOOM,
                SoundCategory.PLAYERS, 0.8f, 1.2f);
        nosebleed(p);
    }

    public static void nosebleed(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        w.spawnParticles(DustParticleEffect.DEFAULT, p.getX(), p.getEyeY() - 0.15, p.getZ(),
                6, 0.12, 0.05, 0.12, 0.0);
        p.addExhaustion(2.0f);
        if (p.getHealth() > 4.0f) {
            p.damage(w.getDamageSources().magic(), 1.0f);
        }
    }
}
