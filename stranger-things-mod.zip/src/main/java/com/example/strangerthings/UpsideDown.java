package com.example.strangerthings;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

/** Измерение «Изнанка». Вход и выход: команда /upsidedown. */
public final class UpsideDown {
    public static final RegistryKey<World> KEY =
            RegistryKey.of(RegistryKeys.WORLD, new Identifier(StrangerThings.MOD_ID, "upside_down"));

    private UpsideDown() {
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("upsidedown").executes(ctx -> {
                    ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                    return travel(p) ? 1 : 0;
                })));
    }

    private static boolean travel(ServerPlayerEntity p) {
        MinecraftServer server = p.getServer();
        if (server == null) return false;

        RegistryKey<World> destKey = p.getWorld().getRegistryKey().equals(KEY) ? World.OVERWORLD : KEY;
        ServerWorld dest = server.getWorld(destKey);
        if (dest == null) {
            p.sendMessage(Text.literal("Изнанка не найдена. Создайте новый мир с этим модом."), false);
            return false;
        }

        int x = p.getBlockX();
        int z = p.getBlockZ();
        int y = dest.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);

        p.getServerWorld().playSound(null, p.getX(), p.getY(), p.getZ(),
                SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0f, 0.5f);
        p.teleport(dest, x + 0.5, y, z + 0.5, p.getYaw(), p.getPitch());
        dest.playSound(null, x + 0.5, y, z + 0.5,
                SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0f, 0.5f);
        return true;
    }
}
